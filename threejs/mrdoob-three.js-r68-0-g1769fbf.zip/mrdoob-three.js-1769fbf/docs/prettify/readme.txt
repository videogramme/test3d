Prettify syntax highlighter:
http://code.google.com/p/google-code-prettify/

Code license - Apache License 2.0
http://www.apache.org/licenses/LICENSE-2.0