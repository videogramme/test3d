/**
 * Entry point for the Isomer API
 */
module.exports = require('./js/isomer');
