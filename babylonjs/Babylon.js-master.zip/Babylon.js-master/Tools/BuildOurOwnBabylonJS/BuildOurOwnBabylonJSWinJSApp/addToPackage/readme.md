Put your demo files in this folder.
You can use sub-folders.
All files/folders will be added to the package during application packaging.