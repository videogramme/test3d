This is version 2.0 of the Mvp.Xml library.
Find more info at http://www.mvpxml.org