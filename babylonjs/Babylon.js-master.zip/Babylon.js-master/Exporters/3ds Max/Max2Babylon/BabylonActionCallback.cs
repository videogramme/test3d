﻿using Autodesk.Max.Plugins;

namespace Max2Babylon
{
    class BabylonActionCallback : ActionCallback
    {
    }
}
